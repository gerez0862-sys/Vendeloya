import express from 'express';
import multer from 'multer';
import OpenAI from 'openai';
import dotenv from 'dotenv';

dotenv.config();
const app = express();
const upload = multer({storage: multer.memoryStorage(), limits:{fileSize:8*1024*1024}});
const client = new OpenAI({apiKey: process.env.OPENAI_API_KEY});
const model = process.env.OPENAI_MODEL || 'gpt-5.6-luna';

app.use(express.static('public'));

app.post('/api/analyze', upload.single('photo'), async (req,res)=>{
  try {
    if(!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY.includes('pega_tu'))
      return res.status(500).json({error:'Falta configurar OPENAI_API_KEY en el archivo .env'});
    if(!req.file) return res.status(400).json({error:'No se recibió ninguna foto.'});
    const mime=req.file.mimetype;
    if(!mime.startsWith('image/')) return res.status(400).json({error:'El archivo debe ser una imagen.'});
    const dataUrl=`data:${mime};base64,${req.file.buffer.toString('base64')}`;

    const response=await client.responses.create({
      model,
      input:[{role:'user',content:[
        {type:'input_text',text:`Analiza esta foto como asistente de ventas. Identifica el producto con cautela; si no puedes determinar marca, modelo, talle, color o precio, no los inventes. Devuelve SOLO JSON válido con estas claves: producto, categoria, detalles_visibles, titulo, descripcion, precio_sugerido, moneda, hashtags, guion_reel. precio_sugerido debe ser null si no hay contexto suficiente para estimarlo. En descripcion usa español rioplatense, claro y vendedor, sin afirmaciones no visibles.`},
        {type:'input_image',image_url:dataUrl,detail:'high'}
      ]}]
    });

    const raw=response.output_text?.trim() || '';
    let data;
    try { data=JSON.parse(raw); }
    catch { data={producto:'Producto identificado',categoria:'',detalles_visibles:'',titulo:'Publicación lista',descripcion:raw,precio_sugerido:null,moneda:'ARS',hashtags:[],guion_reel:''}; }
    res.json(data);
  } catch(err){
    console.error(err);
    res.status(500).json({error:err?.message || 'No se pudo analizar la imagen.'});
  }
});

app.listen(process.env.PORT || 3000,()=>console.log(`VendeloYa listo en http://localhost:${process.env.PORT||3000}`));
